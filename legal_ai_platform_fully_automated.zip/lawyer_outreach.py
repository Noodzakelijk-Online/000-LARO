# Automated Lawyer Outreach System for Legal AI Platform

import datetime
import json
import time
import random
import smtplib
import email.utils
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
from typing import List, Dict, Any, Optional, Tuple

class LawyerOutreachSystem:
    """
    System for automating email outreach to legal professionals in the Netherlands.
    Features include:
    - Targeted outreach based on legal field expertise
    - Automated pre-assessment request (Willing, Able, Ready)
    - Automated follow-up scheduling
    - Response tracking
    - Performance analytics
    """
    
    def __init__(self, case_id: int, user_id: int):
        """Initialize the outreach system for a specific case."""
        self.case_id = case_id
        self.user_id = user_id
        self.outreach_records = []
        self.responses = []
        self.follow_ups_sent = 0
        self.start_time = datetime.datetime.now()
    
    def load_lawyer_database(self, legal_field: str = None) -> List[Dict[str, Any]]:
        """
        Load lawyers from the database, optionally filtered by legal field.
        (Simulated data)
        """
        legal_fields = [
            'family_law', 'criminal_law', 'corporate_law', 'employment_law',
            'real_estate_law', 'immigration_law', 'intellectual_property_law', 'tax_law'
        ]
        cities = [
            'Amsterdam', 'Rotterdam', 'The Hague', 'Utrecht', 'Eindhoven',
            'Groningen', 'Tilburg', 'Almere', 'Breda', 'Nijmegen'
        ]
        sample_lawyers = []
        for i in range(1, 101):
            lawyer_fields = random.sample(legal_fields, random.randint(1, 3))
            if legal_field and legal_field not in lawyer_fields:
                continue
            lawyer = {
                'lawyer_id': i,
                'nova_id': f"NOVA{100000 + i}",
                'email': f"lawyer{i}@example.com",
                'first_name': f"FirstName{i}",
                'last_name': f"LastName{i}",
                'phone': f"+31 6 {random.randint(10000000, 99999999)}",
                'firm_name': f"Law Firm {i // 5 + 1}",
                'city': random.choice(cities),
                'legal_fields': lawyer_fields,
                'response_rate': random.uniform(0.1, 0.6),
                'acceptance_rate': random.uniform(0.01, 0.1),
                'is_active': random.random() > 0.1
            }
            sample_lawyers.append(lawyer)
        if legal_field:
            print(f"Loaded {len(sample_lawyers)} lawyers specializing in {legal_field}")
        else:
            print(f"Loaded {len(sample_lawyers)} lawyers from all fields")
        return sample_lawyers
    
    def prepare_email_content(self, lawyer: Dict[str, Any], case_summary: str, 
                             is_follow_up: bool = False, follow_up_count: int = 0) -> Dict[str, str]:
        """
        Prepare personalized email content, including pre-assessment request.
        """
        current_date = datetime.datetime.now().strftime("%d %B %Y")
        legal_fields_str = ', '.join(lawyer['legal_fields'])

        if not is_follow_up:
            # Initial outreach with Pre-Assessment Request
            subject = f"Case Inquiry & Availability Check: Representation in {legal_fields_str}"
            
            body = f"""
Dear {lawyer['first_name']} {lawyer['last_name']},

I hope this email finds you well. Our AI-driven Legal Outreach Platform is contacting you on behalf of a potential client seeking representation in {legal_fields_str}.

**Case Summary:**
{case_summary}

Based on your expertise (registered with NOvA), we believe you may be suitable for this case.

**Pre-Assessment Request:**
To streamline the process for the client, could you please briefly indicate your status regarding this potential case by replying with ONE of the following options?

1.  **INTERESTED**: You are potentially willing, able (expertise matches), and have the capacity to consider this case further.
2.  **MORE INFO**: You need more details before deciding.
3.  **UNAVAILABLE**: You are unable to take this case at this time (due to capacity, conflict, or other reasons).

If you reply with "INTERESTED", we will promptly provide the full case details for your review.

Thank you for your time and consideration. We look forward to your response.

Best regards,
Legal AI Reach Out Platform
On behalf of the client
{current_date}
            """
        else:
            # Follow-up email (simplified, assumes initial email had pre-assessment)
            follow_up_phrases = [
                "I wanted to follow up on my previous email",
                "I am writing to follow up on the legal case inquiry and availability check I sent recently",
                "I'm checking in regarding the representation request and availability check I sent earlier"
            ]
            urgency_phrases = [
                "The client is eager to secure representation soon.",
                "The client would appreciate a timely response as they need to proceed with their case.",
                "As time is of the essence for this matter, a prompt response would be greatly appreciated."
            ]
            subject = f"Follow-up: Case Inquiry & Availability Check ({follow_up_count + 1})"
            
            body = f"""
Dear {lawyer['first_name']} {lawyer['last_name']},

{random.choice(follow_up_phrases)} regarding a client seeking representation in {legal_fields_str}.

**Case Summary Recap:**
{case_summary}

We kindly request a brief response indicating if you are INTERESTED, need MORE INFO, or are UNAVAILABLE for this potential case, as outlined in the previous email.

{random.choice(urgency_phrases)}

Thank you for your time and consideration.

Best regards,
Legal AI Reach Out Platform
On behalf of the client
{current_date}
            """
        
        return {
            'subject': subject,
            'body': body.strip()
        }
    
    def send_email(self, lawyer: Dict[str, Any], email_content: Dict[str, str], 
                  attachments: List[str] = None) -> Dict[str, Any]:
        """
        Send an email to a lawyer (Simulated).
        """
        outreach_id = len(self.outreach_records) + 1
        timestamp = datetime.datetime.now()
        outreach_record = {
            'outreach_id': outreach_id,
            'case_id': self.case_id,
            'lawyer_id': lawyer['lawyer_id'],
            'lawyer_name': f"{lawyer['first_name']} {lawyer['last_name']}",
            'lawyer_email': lawyer['email'],
            'subject': email_content['subject'],
            'is_follow_up': 'Follow-up' in email_content['subject'],
            'follow_up_count': email_content['subject'].count('Follow-up'),
            'sent_timestamp': timestamp.isoformat(),
            'has_attachments': bool(attachments),
            'status': 'sent',
            'response_received': False,
            'response_timestamp': None,
            'response_type': None # e.g., 'pre_assessment_positive', 'pre_assessment_negative', 'more_info', 'no_response'
        }
        self.outreach_records.append(outreach_record)
        print(f"Email sent to {lawyer['email']} with subject: {email_content['subject']}")
        return outreach_record
    
    def send_initial_outreach(self, case_summary: str, legal_field: str, 
                             max_lawyers: int = 50) -> List[Dict[str, Any]]:
        """
        Send initial outreach emails with pre-assessment request.
        """
        lawyers = self.load_lawyer_database(legal_field)
        lawyers.sort(key=lambda x: x['response_rate'], reverse=True)
        target_lawyers = lawyers[:max_lawyers]
        outreach_records = []
        for lawyer in target_lawyers:
            email_content = self.prepare_email_content(lawyer, case_summary)
            outreach_record = self.send_email(lawyer, email_content)
            outreach_records.append(outreach_record)
            time.sleep(0.05) # Reduced delay for simulation
        print(f"Sent initial outreach with pre-assessment request to {len(outreach_records)} lawyers specializing in {legal_field}")
        return outreach_records
    
    def check_for_responses(self) -> List[Dict[str, Any]]:
        """
        Check for responses and categorize them based on pre-assessment keywords (Simulated).
        """
        new_responses = []
        for record in self.outreach_records:
            if not record['response_received']:
                response_chance = 0.3 if not record['is_follow_up'] else 0.15
                if random.random() < response_chance:
                    timestamp = datetime.datetime.now()
                    
                    # Simulate response content and determine type
                    response_type_rand = random.random()
                    simulated_reply_body = ""
                    if response_type_rand < 0.2: # 20% positive pre-assessment
                        response_type = 'pre_assessment_positive'
                        simulated_reply_body = random.choice(["INTERESTED", "Yes, interested.", "Send more details, I'm interested."])
                    elif response_type_rand < 0.5: # 30% request more info
                        response_type = 'more_info'
                        simulated_reply_body = random.choice(["MORE INFO", "Need more details.", "Can you provide the full file?"])
                    else: # 50% unavailable/negative
                        response_type = 'pre_assessment_negative'
                        simulated_reply_body = random.choice(["UNAVAILABLE", "Not taking new cases.", "Conflict of interest.", "Not my area."])
                    
                    record['response_received'] = True
                    record['response_timestamp'] = timestamp.isoformat()
                    record['response_type'] = response_type
                    record['status'] = 'responded'
                    
                    response = {
                        'response_id': len(self.responses) + 1,
                        'outreach_id': record['outreach_id'],
                        'lawyer_id': record['lawyer_id'],
                        'lawyer_name': record['lawyer_name'],
                        'lawyer_email': record['lawyer_email'],
                        'timestamp': timestamp.isoformat(),
                        'response_type': response_type,
                        'content': simulated_reply_body
                    }
                    self.responses.append(response)
                    new_responses.append(response)
        
        if new_responses:
            print(f"Received and categorized {len(new_responses)} new responses")
        return new_responses
    
    def schedule_follow_ups(self, days_to_wait: int = 3) -> List[Dict[str, Any]]:
        """
        Schedule follow-up emails for outreach with no response.
        """
        follow_up_needed = []
        current_time = datetime.datetime.now()
        for record in self.outreach_records:
            if not record['response_received']:
                sent_time = datetime.datetime.fromisoformat(record['sent_timestamp'])
                days_elapsed = (current_time - sent_time).days
                if days_elapsed >= days_to_wait and record['follow_up_count'] < 2:
                    follow_up_needed.append(record)
        if follow_up_needed:
             print(f"Scheduled {len(follow_up_needed)} follow-up emails")
        return follow_up_needed
    
    def send_follow_ups(self, case_summary: str) -> List[Dict[str, Any]]:
        """
        Send follow-up emails for outreach with no response.
        """
        follow_up_needed = self.schedule_follow_ups()
        new_outreach_records = []
        if not follow_up_needed:
             return []
             
        lawyers_db = self.load_lawyer_database() # Load once for efficiency
        lawyer_map = {l['lawyer_id']: l for l in lawyers_db}

        for record in follow_up_needed:
            lawyer = lawyer_map.get(record['lawyer_id'])
            if lawyer:
                follow_up_count = record['follow_up_count']
                email_content = self.prepare_email_content(
                    lawyer, case_summary, is_follow_up=True, follow_up_count=follow_up_count
                )
                outreach_record = self.send_email(lawyer, email_content)
                new_outreach_records.append(outreach_record)
                record['follow_up_count'] += 1
                self.follow_ups_sent += 1
                time.sleep(0.05)
        
        if new_outreach_records:
            print(f"Sent {len(new_outreach_records)} follow-up emails")
        return new_outreach_records
    
    def get_interested_lawyers(self) -> List[Dict[str, Any]]:
        """
        Get lawyers who responded positively to the pre-assessment ('INTERESTED').
        
        Returns:
            List of lawyer dictionaries who are interested.
        """
        interested_responses = [r for r in self.responses if r['response_type'] == 'pre_assessment_positive']
        interested_lawyer_ids = set(r['lawyer_id'] for r in interested_responses)
        
        if not interested_lawyer_ids:
            print("No lawyers responded as 'INTERESTED' yet.")
            return []

        # Load full lawyer details for interested ones
        lawyers_db = self.load_lawyer_database()
        interested_lawyers = [l for l in lawyers_db if l['lawyer_id'] in interested_lawyer_ids]
        
        print(f"Found {len(interested_lawyers)} lawyers who responded 'INTERESTED'")
        return interested_lawyers

    # get_accepted_cases is less relevant now, replaced by get_interested_lawyers
    # def get_accepted_cases(self) -> List[Dict[str, Any]]: ...
    
    def get_outreach_statistics(self) -> Dict[str, Any]:
        """
        Calculate statistics for the outreach campaign.
        """
        total_outreach = len(self.outreach_records)
        unique_lawyers = len(set(r['lawyer_id'] for r in self.outreach_records))
        responses_received = len(self.responses)
        response_rate = responses_received / total_outreach if total_outreach > 0 else 0
        
        interested_lawyers = len([r for r in self.responses if r['response_type'] == 'pre_assessment_positive'])
        interest_rate = interested_lawyers / responses_received if responses_received > 0 else 0
        
        more_info_requests = len([r for r in self.responses if r['response_type'] == 'more_info'])
        unavailable_responses = len([r for r in self.responses if r['response_type'] == 'pre_assessment_negative'])
        
        follow_ups_sent = self.follow_ups_sent
        elapsed_time_hours = (datetime.datetime.now() - self.start_time).total_seconds() / 3600
        
        stats = {
            'total_outreach_emails': total_outreach,
            'unique_lawyers_contacted': unique_lawyers,
            'responses_received': responses_received,
            'response_rate': f"{response_rate:.1%}",
            'interested_lawyers': interested_lawyers,
            'interest_rate_of_responders': f"{interest_rate:.1%}",
            'more_info_requests': more_info_requests,
            'unavailable_responses': unavailable_responses,
            'follow_ups_sent': follow_ups_sent,
            'elapsed_time_hours': round(elapsed_time_hours, 2)
        }
        return stats

# Example Usage
if __name__ == '__main__':
    case_id = 101
    user_id = 55
    legal_field_needed = 'employment_law'
    summary = "Client was unfairly dismissed after reporting safety concerns. Seeking compensation and reinstatement. Evidence includes emails and witness statements."

    outreach_system = LawyerOutreachSystem(case_id, user_id)

    # Send initial outreach with pre-assessment
    outreach_system.send_initial_outreach(summary, legal_field_needed, max_lawyers=20)

    # Simulate time passing and check for responses
    print("\n--- Simulating time passing (checking responses) ---")
    time.sleep(1)
    outreach_system.check_for_responses()

    # Simulate more time and send follow-ups
    print("\n--- Simulating more time (sending follow-ups) ---")
    # Manually adjust sent_timestamp for simulation if needed, or just rely on schedule_follow_ups logic
    outreach_system.send_follow_ups(summary)

    # Check for responses again after follow-ups
    print("\n--- Simulating time passing after follow-ups ---")
    time.sleep(1)
    outreach_system.check_for_responses()

    # Get lawyers who are interested
    print("\n--- Identifying Interested Lawyers ---")
    interested = outreach_system.get_interested_lawyers()
    if interested:
        print("Interested lawyers found:")
        for lawyer in interested:
            print(f"- {lawyer['first_name']} {lawyer['last_name']} ({lawyer['email']})")
    
    # Get final statistics
    print("\n--- Final Outreach Statistics ---")
    stats = outreach_system.get_outreach_statistics()
    print(json.dumps(stats, indent=2))

